# Information-theory-and-code
there are some pdf collection of course about Information theory and code in WUHT 
